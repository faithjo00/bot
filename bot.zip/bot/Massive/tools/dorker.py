from bs4 import BeautifulSoup
import requests

r, g, b, c, m, y, w, bo, un = "\033[0;31;40m","\033[0;32;40m","\033[0;34;40m","\033[0;36m",'\033[95m',"\033[0;33;40m","\033[0m","\033[1m","\033[4m"

class dorker(object):

    def __init__(self, dork, pages, proxy):
        self.dork = dork
        self.page_ammount = pages
        self.domains_bing = []
        self.proxy_required = proxy
        self.first_page_links = []

    def filter_and_adding(self, domains_list):
        data = open('blacklist.txt').readlines()
        new_data = [items.rstrip() for items in data]
        for domains in domains_list:
            domain_data = domains.split('/')
            new_domain = domain_data[0]+"//"+domain_data[2]+'/'
            if new_domain not in new_data:
                self.domains_bing.append(new_domain)
                print(new_domain, file=open('grabbed.txt', 'a'))

    def first_page(self):
        try:
            url = "https://www.bing.com/search?q=" + self.dork + "&first=" + '1' + "&FORM=PERE"
            header = {
                'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:47.0) Gecko/20100101 Firefox/47.0'
            }
            source_code = requests.get(url, headers=header).text
            keyword = '<li class="b_algo"><h2><a href="'
            split_data = source_code.split(keyword)
            for x in range(10):
                links_ = split_data[x + 1].split('"')[0]
                self.first_page_links.append(links_)
        except IndexError:
            pass

    def searcher(self):
        for i in range(self.page_ammount):
            url = "https://www.bing.com/search?q=" + self.dork +"&first=" + str(i)+'1' + "&FORM=PERE"

            print(f"\n{g}{bo}[+] Page {y}{i}\n{w}")
            header = {
                'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:47.0) Gecko/20100101 Firefox/47.0'
            }
            try:
                source_code = requests.get(url,headers=header).text
                keyword = '<li class="b_algo"><h2><a href="'
                split_data = source_code.split(keyword)
                temporary_domain_list = []
                try:
                    for x in range(10):
                        links_ = split_data[x+1].split('"')[0]
                        temporary_domain_list.append(links_)
                        print(f'[-] '+links_)

                except IndexError:
                    pass

                self.filter_and_adding(temporary_domain_list)


            except requests.exceptions.HTTPError:
                print(f'{r}[-] Http error{w}')
                continue
            except requests.exceptions.ConnectTimeout:
                print(f'{r}[-] Connection timed out{w}')
                continue
            except requests.exceptions.Timeout:
                print(f'{r}[-] Timeout{w}')
                continue

            if i != 0:
                if self.first_page_links == temporary_domain_list:
                    print(f'{bo}[!] Removing duplicates{w}')
                    break

    def start(self):

        self.first_page()
        self.searcher()

        print(f'\n{g}{bo}[+] Total sites scrapped {y}{len(self.domains_bing)}{w}')
        print(f'\n{g}[+] {bo}Result Saved {w}-> {y}grabbed.txt\n{w}')