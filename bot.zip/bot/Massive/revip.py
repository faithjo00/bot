import os
import re
from multiprocessing.dummy import Pool as ThreadPool

import requests
from http_request_randomizer.requests.proxy.requestProxy import RequestProxy

req_proxy = RequestProxy()
os.system('cls' if os.name == 'nt' else 'clear')

def viewdns(i):

    try:
        i = i.replace('\n', '').replace('\r', '')
        api = 'https://viewdns.info/reverseip/?host=' + i + '&t=1'
        while True:
            try:
                request = req_proxy.generate_proxied_request(api)
                if '.' in request.text:
                    refin = re.findall('</tr><tr> <td>(.*?)</td><td align="center">', request.text)
                    for i in refin:
                        if i.startswith("http//"):
                            print 'http://'+i
                            open('site.txt', "a").write('http://'+i + "\n")
                        elif i.startswith("https//"):
                            print 'http://'+i
                            open('site.txt', "a").write('http://'+i + "\n")
                        else:
                            print 'http://'+i
                            open('site.txt', "a").write('http://'+i + "\n")
                    break
            except:
                continue
    except:
        pass
        print '[!] Request timed out'

ListPass = open(raw_input("[-] Enter IP Address file list: "), 'r').readlines()
pool = ThreadPool(100)
pool.map(viewdns, ListPass)
pool.close()
pool.join()

if __name__ == '__main__':
    print("[!] File saved -> site.txt")
