import os
import re
from multiprocessing.dummy import Pool
import requests
from http_request_randomizer.requests.proxy.requestProxy import RequestProxy
import logging

logging.disable(logging.DEBUG)
logging.disable(logging.INFO)

req_proxy = RequestProxy()
os.system('cls' if os.name == 'nt' else 'clear')

def rev(i):
    try:
        i = i.replace('\n', '').replace('\r', '')
        api = 'https://viewdns.info/reverseip/?host=' + i + '&t=1'
        while True:
            request = req_proxy.generate_proxied_request(api)
            try:
                if '.' in request.text:
                    refin = re.findall('</tr><tr> <td>(.*?)</td><td align="center">', request.text)
                    for i in refin:
                        if i.startswith('http://'):
                            print(i)
                            open('result.txt', 'a').write('http://' + i + '\n')
                        elif i.startswith('https://'):
                            print(i)
                            open('result.txt', 'a').write('https://' + i + '\n')
                        else:
                            print(i)
                            open('result.txt', 'a').write(i + '\n')
                    break
            except:
                continue
    except:
        pass


def start():
    ipaddr = open(input('[-] Enter IP Address list: '), 'r').readlines()
    threads = int(input('[-] Enter threads: '))
    pool = Pool(threads)
    pool.map(rev, ipaddr)
    pool.close()
    pool.join()

if __name__ == '__main__':
    print('[+] Result saved -> result.txt')