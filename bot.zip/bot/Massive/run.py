import requests, httplib, urllib, urllib3, urllib2, codecs
from urllib import urlopen as o
import socket
from platform import system
import os
import sys, time
import re
import threading
from multiprocessing.dummy import Pool
import datetime
from time import time as timer	
import time, random
from random import sample as rand
from pprint import pprint
from urlparse import urlparse
import cookielib
from bs4 import BeautifulSoup
from platform import system
from lxml.html import fromstring
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from http_request_randomizer.requests.proxy.requestProxy import RequestProxy

requests.packages.urllib3.disable_warnings (InsecureRequestWarning)

user = {"User-Agent": "Mozilla/5.0 (Windows NT 6.1; rv:57.0) Gecko/20100101 Firefox/57.0"}

def cls():
    os.system('cls' if os.name == 'nt' else 'clear')

def zoneh():

    notif = "http://www.zone-h.org/archive/notifier="
    onhold = "http://zone-h.org/archive/published=0"
    
    print '[-] Zone-h Grabber\n\n[1] Grab sites from notifier\n[2] Grab sites from onhold\n'
    pil = int(raw_input('[-] Enter choice: '))

    if pil == 1:

        notifier = raw_input('[-] Enter notifier: ')
        phpsessid, zhe = raw_input('[-] Enter PHPSESSID ZHE: ').split(' ')

        cooc = {
            "PHPSESSID": phpsessid,
            "ZHE": zhe
        }

        for i in range(1, 51):
            zh = requests.get(notif + notifier + '/page=' + str(i), cookies = cooc)
            zhorg = zh.content
            print(notif + notifier + "/page=" + str(i))
            if '<html><body>-<script type="text/javascript"' in zhorg:
                print '[!] Enter captcha'
                sys.exit()
            elif '<input type="text" name="captcha" value=""><input type="submit">' in zhorg:
                print '[-] Cookies expired'
                sys.exit()
            else:
                urls = re.findall('<td>(.*)\n							</td>', zhorg)
                if '/mirror/id' in zhorg:
                    for x in urls:
                        url = x.replace('...', '')
                        print(url.split('/'))[0]
                        with open('output.txt', 'a') as f:
                            f.write(url.split('/')[0] + '\n')
                else:
                    print '[!] Grabbed'
                    sys.exit()
    
    elif pil == 2:

        phpsessid, zhe = raw_input('[-] Enter PHPSESSID ZHE: ').split(' ')

        cooc = {
            "PHPSESSID": phpsessid,
            "ZHE": zhe
        }

        for i in range(1, 51):
            zh = requests.get(onhold + '/page=' + str(i), cookies = cooc)
            zhorg = zh.content
            if '<html><body>-<script type="text/javascript"' in zhorg:
                print '[!] Enter captcha'
                sys.exit()
            elif '<input type="text" name="captcha" value=""><input type="submit">' in zhorg:
                print '[-] Cookies expired'
                sys.exit()
            else:
                urls = re.findall('<td>(.*)\n							</td>', zhorg)
                if '/mirror/id' in zhorg:
                    for x in urls:
                        url = x.replace('...', '')
                        print(url.split('/'))[0]
                        with open('output.txt', 'a') as f:
                            f.write(url.split('/')[0] + '\n')
                else:
                    print '[!] Grabbed'
                    sys.exit()
                
def ip():

    file = raw_input('[-] Enter domain list: ')
    with open(file) as f:
        for i in f:
            host = i.strip()
            try:
                if 'http://' not in host:
                    ip = socket.gethostbyname(host)
                    print ip
                    open('ip.txt', 'a').write(ip + '\n')
                elif 'http://' in host:
                    domain = host.replace('http://', '').replace('https://', '')
                    print ip
                    open('ip.txt', 'a').write(ip)

            except:
                pass
def bing():

    inp = raw_input('[-] Enter IP Address list file: ')
    inp = open(inp, 'r')

    for i in inp:
        x = []
        y = 1
        while y < 299:
            host = "http://www.bing.com/search?q=IP%3A"+i+"+&count=50&first="+str(y)
            getReq = requests.get(host, verify=False, headers=user)
            reqq = getReq.content
            requ = re.findall('<h2><a href="(.*?)"', reqq)
            for z in requ:
                xz = z.split('/')
                if (xz[0] + '//' + xz[2]) in x:
                    pass
                else:
                    x.append(xz[0] + '//' + xz[2])
                    print(xz[0] + '//' + xz[2])
                    with open('grabbed.txt', 'a') as file:
                        file.writelines((xz[0] + '//' + xz[2]) + '\n')
                    y = y + 50

def hackertarget():
    inp = raw_input('[-] Enter IP Address list file: ')
    inp = open(inp, 'r')
    for i in inp.readlines():
        splitted = i.rstrip()
        try:
            ip = splitted.rstrip()
            api = 'http://api.hackertarget.com/reverseiplookup/?q='+ip
            req_proxy = RequestProxy()
            try:
                request = req_proxy.generate_proxied_request(api)
                if 'error' in request.text or 'No DNS' in request.text:
                        break
                if 'API count exceeded' in request.text or 'Bad Request' in request.text:
                    continue
                else:
                    print(request.content)
                    with open('sites.txt', 'a') as file:
                        file.writelines(request.content + '\n')
                    break

            except:
                pass

        except:
            pass
def rmdup():

    i = raw_input('[-] Enter file name or path: ')
    output = raw_input('[-] Enter output file name: ')
    if __name__ == '__main__':
        f = open(output, 'w+')
        flag = False
        with open(i) as fp:
            for line in fp:
                for temp in f:
                    if temp == line:
                        flag = True
                        break
                if flag == False:
                    f.write(line)
                elif flag == True:
                    flag = False
                f.seek(0)
            f.close()
    print '[!] Removed'

cls()

print '[-] Coded by Aril\n\n[1] Zone-h Grabber\n[2] Mass Domain to IP Address converter\n[3] Mass viewdns Reverse IP Unlimited\n[4] Mass Bing Reverse IP\n[5] Remove Duplicate\n'

pilihan = int(raw_input('[-] Enter choice: '))

try:
    if pilihan == 1:
        cls()
        zoneh()
    elif pilihan == 2:
        cls()
        ip()
    elif pilihan == 3:
        cls()
        if system() == 'Linux':
            os.system("python revip.py")
        if system() == 'Windows':
            os.system('revip.py')
    elif pilihan == 4:
        cls()
        bing()
    elif pilihan == 5:
        cls()
        rmdup()
    elif pilihan == 6:
        cls()
        hackertarget()
    else:
        cls()
        print 'Go fuck yourself!'
except:
    pass
