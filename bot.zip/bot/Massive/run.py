import requests
from platform import system
import os, sys, re
import socket
from tools import revip, dorker
from tld import get_tld

r, g, b, c, m, y, w, bo, un = "\033[0;31;40m","\033[0;32;40m","\033[0;34;40m","\033[0;36m",'\033[95m',"\033[0;33;40m","\033[0m","\033[1m","\033[4m"

def cls():
    os.system('cls' if os.name == 'nt' else 'clear')

def urltoip():

    inp = input(f'{bo}[-] Enter URL list file: {w}')
    inp = open(inp, 'r')
    for i in inp.readlines():
        splitted = i.rstrip()
        try:
            url = splitted.rstrip()
            res = get_tld(url, as_object=True)
            ip = socket.gethostbyname(res.fld)
            print(ip)
            open('ip.txt', 'a').write(ip + '\n')
        except:
            pass

def bing():

    inp = input(f'{bo}[-] Enter IP Address list file: {w}')
    inp = open(inp, 'r')

    for i in inp:
        x = []
        y = 1
        while y < 299:
            host = "http://www.bing.com/search?q=IP%3A"+i+"+&count=50&first="+str(y)
            getReq = requests.get(host, verify=False, headers=user)
            reqq = getReq.content
            requ = re.findall('<h2><a href="(.*?)"', reqq)
            for z in requ:
                xz = z.split('/')
                if (xz[0] + '//' + xz[2]) in x:
                    pass
                else:
                    x.append(xz[0] + '//' + xz[2])
                    print(xz[0] + '//' + xz[2])
                    with open('binged.txt', 'a') as file:
                        file.writelines((xz[0] + '//' + xz[2]) + '\n')
                    y = y + 50

def rmdup():

    i = input(f'{bo}[-] Enter file name or path: {w}')
    if __name__ == '__main__':
        f = open('removed.txt', 'w+')
        flag = False
        with open(i) as fp:
            for line in fp:
                for temp in f:
                    if temp == line:
                        flag = True
                        break
                if flag == False:
                    f.write(line)
                elif flag == True:
                    flag = False
                f.seek(0)
            f.close()

    print(f'{bo}[!] Removed {w}-> removed.txt{w}')

def zoneh():

    notif = "http://www.zone-h.org/archive/notifier="
    onhold = "http://zone-h.org/archive/published=0"
    
    print(f'{bo}[-] Zone-h Grabber\n\n[1] Grab sites from notifier\n[2] Grab sites from onhold{w}\n')
    pil = int(input('[-] Enter choice: '))

    if pil == 1:

        notifier = input(f'{bo}[-] Enter notifier: {w}')
        phpsessid, zhe = input(f'{bo}[-] Enter PHPSESSID ZHE: {w}').split(' ')

        cooc = {
            "PHPSESSID": phpsessid,
            "ZHE": zhe
        }

        for i in range(1, 51):
            zh = requests.get(notif + notifier + '/page=' + str(i), cookies = cooc)
            zhorg = zh.content
            print(notif + notifier + "/page=" + str(i))
            if '<html><body>-<script type="text/javascript"' in zhorg:
                print('[-] Enter captcha')
                sys.exit()
            elif '<input type="text" name="captcha" value=""><input type="submit">' in zhorg:
                print('[-] Cookies expired')
                sys.exit()
            else:
                urls = re.findall('<td>(.*)\n							</td>', zhorg)
                if '/mirror/id' in zhorg:
                    for x in urls:
                        url = x.replace('...', '')
                        print(url.split('/')[0])
                        with open('zh.txt', 'a') as f:
                            f.write(url.split('/')[0] + '\n')
                else:
                    print(f'\n{g}{bo}[!] Grabbed{w}')
                    print(f'\n{g}{bo}[+] Result saved {w}-> {y}zh.txt{w}')
                    sys.exit()
    
    elif pil == 2:

        phpsessid, zhe = input(f'{bo}[-] Enter PHPSESSID ZHE: {w}').split(' ')

        cooc = {
            "PHPSESSID": phpsessid,
            "ZHE": zhe
        }

        for i in range(1, 51):
            zh = requests.get(onhold + '/page=' + str(i), cookies = cooc)
            zhorg = zh.content
            if '<html><body>-<script type="text/javascript"' in zhorg:
                print('[-] Enter captcha')
                sys.exit()
            elif '<input type="text" name="captcha" value=""><input type="submit">' in zhorg:
                print('[-] Cookies expired')
                sys.exit()
            else:
                urls = re.findall('<td>(.*)\n							</td>', zhorg)
                if '/mirror/id' in zhorg:
                    for x in urls:
                        url = x.replace('...', '')
                        print(url.split('/')[0])
                        with open('zh.txt', 'a') as f:
                            f.write(url.split('/')[0] + '\n')
                else:
                    print(f'\n{g}{bo}[!] Grabbed{w}')
                    print(f'\n{g}{bo}[+] Result saved {w}-> {y}zh.txt{w}')
                    sys.exit()

cls()
print(f'{bo}\n[-] Coded by Aril\n\n[1] Zone-h Grabber\n[2] Mass Reverse IP Unlimited\n[3] Bing Dorker\n[4] Bing URL Grabber Bulk\n[5] URL to IP Address\n[6] Remove Duplicates\n{w}')

pilihan = int(input(f'{bo}[-] Enter choice: {w}'))

try:
    while True:
        if pilihan == 1:
            cls()
            zoneh()
            break
        elif pilihan == 2:
            cls()
            revip.start()
            break
        elif pilihan == 3:
            cls()
            dork = input(f'{bo}[-] Enter dork: {w}')
            country = input(f'{bo}[-] Enter country: {w}')
            if country == 'all':
                dorks = dork
            else:
                dorks = dork + ' site:' + country
            pages = input(f'{bo}[-] Enter pages: {w}')
            cls()
            dorker.dorker(dorks, int(pages), False).start()
            break
        elif pilihan == 4:
            cls()
            bing()
            break
        elif pilihan == 5:
            cls()
            urltoip()
            break
        elif pilihan == 6:
            cls()
            rmdup()
            break
        else:
            cls()
            sys.exit()

except KeyboardInterrupt:
    print(f'{bo}Go fuck yourself!{w}')
