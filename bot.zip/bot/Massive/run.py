import requests
import socket
from platform import system
import os
import sys, time
import re
import threading
from multiprocessing.dummy import Pool
import datetime
from time import time as timer	
import time, random
from random import sample as rand
from bs4 import BeautifulSoup
from platform import system
from lxml.html import fromstring
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from http_request_randomizer.requests.proxy.requestProxy import RequestProxy
from tld import get_tld

requests.packages.urllib3.disable_warnings (InsecureRequestWarning)

R, G, B, C, M, Y = "\033[0;31;40m","\033[0;32;40m","\033[0;34;40m","\033[0;36m",'\033[95m',"\033[0;33;40m"
BOLD, UNDER, END = '\033[1m','\033[4m','\033[0m'

user = {"User-Agent": "Mozilla/5.0 (Windows NT 6.1; rv:57.0) Gecko/20100101 Firefox/57.0"}

def cls():
    os.system('cls' if os.name == 'nt' else 'clear')

def zoneh():

    notif = "http://www.zone-h.org/archive/notifier="
    onhold = "http://zone-h.org/archive/published=0"
    
    print(f'{BOLD}[-] Zone-h Grabber\n\n[1] Grab sites from notifier\n[2] Grab sites from onhold{END}\n')
    pil = int(input('[-] Enter choice: '))

    if pil == 1:

        notifier = input(f'{G}{BOLD}[-] Enter notifier: {END}')
        phpsessid, zhe = input(f'{BOLD}[-] Enter PHPSESSID ZHE: {END}').split(' ')

        cooc = {
            "PHPSESSID": phpsessid,
            "ZHE": zhe
        }

        for i in range(1, 51):
            zh = requests.get(notif + notifier + '/page=' + str(i), cookies = cooc)
            zhorg = zh.content
            print(notif + notifier + "/page=" + str(i))
            if '<html><body>-<script type="text/javascript"' in zhorg:
                print('[-] Enter captcha')
                sys.exit()
            elif '<input type="text" name="captcha" value=""><input type="submit">' in zhorg:
                print('[-] Cookies expired')
                sys.exit()
            else:
                urls = re.findall('<td>(.*)\n							</td>', zhorg)
                if '/mirror/id' in zhorg:
                    for x in urls:
                        url = x.replace('...', '')
                        print(f'{G}{BOLD}'+url.split('/')[0])
                        with open('output.txt', 'a') as f:
                            f.write(url.split('/')[0] + '\n')
                else:
                    print(f'{G}{BOLD}[!] Grabbed{END}')
                    sys.exit()
    
    elif pil == 2:

        phpsessid, zhe = input(f'{BOLD}[-] Enter PHPSESSID ZHE: {END}').split(' ')

        cooc = {
            "PHPSESSID": phpsessid,
            "ZHE": zhe
        }

        for i in range(1, 51):
            zh = requests.get(onhold + '/page=' + str(i), cookies = cooc)
            zhorg = zh.content
            if '<html><body>-<script type="text/javascript"' in zhorg:
                print('[-] Enter captcha')
                sys.exit()
            elif '<input type="text" name="captcha" value=""><input type="submit">' in zhorg:
                print('[-] Cookies expired')
                sys.exit()
            else:
                urls = re.findall('<td>(.*)\n							</td>', zhorg)
                if '/mirror/id' in zhorg:
                    for x in urls:
                        url = x.replace('...', '')
                        print(f'{G}{BOLD}'+url.split('/')[0])
                        with open('output.txt', 'a') as f:
                            f.write(url.split('/')[0] + '\n')
                else:
                    print(f'{G}{BOLD}[!] Grabbed{END}')
                    sys.exit()
                
def ip():

    file = input(f'{BOLD}[-] Enter domain list: {END}')
    with open(file) as f:
        for i in f:
            host = i.strip()
            try:
                if 'http://' not in host:
                    ip = socket.gethostbyname(host)
                    print(ip)
                    open('ip.txt', 'a').write(ip + '\n')
                elif 'http://' in host:
                    domain = host.replace('http://', '').replace('https://', '')
                    print(ip)
                    open('ip.txt', 'a').write(ip)

            except:
                pass
def bing():

    inp = input(f'{BOLD}[-] Enter IP Address list file: {END}')
    inp = open(inp, 'r')

    for i in inp:
        x = []
        y = 1
        while y < 299:
            host = "http://www.bing.com/search?q=IP%3A"+i+"+&count=50&first="+str(y)
            getReq = requests.get(host, verify=False, headers=user)
            reqq = getReq.content
            requ = re.findall('<h2><a href="(.*?)"', reqq)
            for z in requ:
                xz = z.split('/')
                if (xz[0] + '//' + xz[2]) in x:
                    pass
                else:
                    x.append(xz[0] + '//' + xz[2])
                    print(xz[0] + '//' + xz[2])
                    with open('grabbed.txt', 'a') as file:
                        file.writelines((xz[0] + '//' + xz[2]) + '\n')
                    y = y + 50
def rmdup():

    i = input(f'{BOLD}[-] Enter file name or path: {END}')
    if __name__ == '__main__':
        f = open('removed.txt', 'w+')
        flag = False
        with open(i) as fp:
            for line in fp:
                for temp in f:
                    if temp == line:
                        flag = True
                        break
                if flag == False:
                    f.write(line)
                elif flag == True:
                    flag = False
                f.seek(0)
            f.close()
    print(f'{BOLD}[!] Removed -> removed.txt{END}')


def urltodomain():

    inp = input(f'{BOLD}[-] Enter URL list file: {END}')
    inp = open(inp, 'r')
    for i in inp.readlines():
        splitted = i.rstrip()
        try:
            url = splitted.rstrip()
            res = get_tld(url, as_object=True)
            print(res.fld)
            open('domain.txt', 'a').write(res.fld+'\n')
        except:
            pass

cls()

print(f'{BOLD}\n[-] Coded by Aril\n\n[1] Zone-h Grabber\n[2] Mass Reverse IP Unlimited\n[3] Bing URL Grabber Bulk\n[4] URL to Domain converter\n[5] Domain to IP Address converter\n[6] Remove Duplicates\n{END}')

pilihan = int(input(f'{BOLD}[-] Enter choice: {END}'))

try:
    if pilihan == 1:
        cls()
        zoneh()
    elif pilihan == 2:
        cls()
        if system() == 'Linux':
            os.system("python3 rev.py")
        if system() == 'Windows':
            os.system('rev.py')
    elif pilihan == 3:
        cls()
        bing()
    elif pilihan == 4:
        cls()
        urltodomain()
    elif pilihan == 5:
        cls()
        ip()
    elif pilihan == 6:
        cls()
        rmdup()
    else:
        cls()
        print('Go fuck yourself!')
except:
    pass
