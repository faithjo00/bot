try:
    from http_request_randomizer.requests.proxy.requestProxy import RequestProxy
except Exception as e:
    print('[!] pip install http-request-randomizer')
    exit(0)
from time import time,strftime,gmtime,sleep
from math import ceil
from argparse import ArgumentParser
from urllib.parse import urlparse
import socket, subprocess, platform, concurrent.futures, os, random
if platform.system() == 'Windows':
    cmd = 'cls'
    exc = 'python'
else:
    cmd = 'clear'
    exc = 'python3'
R, G, B, C, M, Y = "\033[0;31;40m","\033[0;32;40m","\033[0;34;40m","\033[0;36m",'\033[95m',"\033[0;33;40m"
BOLD, UNDER, END = '\033[1m','\033[4m','\033[0m'
class reverse:
    def __init__(self, url):
        if not urlparse(url).scheme:
            self.url = f'http://{url}'
            self.url = urlparse(self.url).netloc
        else:
            self.url = urlparse(url).netloc
    def lookup(self):
        try:
            IP   = socket.gethostbyname(self.url)
            SOCK = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            SOCK.settimeout(2)
            LIVE = SOCK.connect_ex((IP,80))
            if LIVE==0:
                CMD  = exc + ' ip.py ' + IP
                GO   = subprocess.check_output(CMD, shell=True, stderr=subprocess.STDOUT)
                return 1, IP
            else:
                return 0
        except Exception as e:
            print(e)

def w666(site):
    global LEN_SITES, SCANNED
    rev = reverse(site)
    if rev.lookup():
        SCANNED += 1
        try:
            with open(rev.lookup()[1]+'.txt', 'r') as f: COUNT = f.read().splitlines()
            print(f'{G}{BOLD}{rev.url} -> {C}{BOLD}{str(len(COUNT))}{END}')
        except:
            print(f'{R}{BOLD}{rev.url}{END}')

    else:
        SCANNED += 1
        print(f'{R}{BOLD}{rev.url}{END}')
if __name__ == '__main__':
    try:
        start = time()
        argpars = ArgumentParser()
        argpars.add_argument('-s', '--target', help="<enter your target website: -s http://site.com>")
        argpars.add_argument('-l', '--list', help="<enter your sites list: -l list_site.txt>")
        argpars.add_argument('-t', '--thread', required=True, type=int, help="<threads: -t 100>")
        SITE      = argpars.parse_args().target
        SITES     = argpars.parse_args().list
        THREADING = argpars.parse_args().thread
        if SITE:
            W = 0
            print(SITE)
            PP = SITE
            LEN_SITES = 1
        if SITES:
            W = 1
            try:
                with open(SITES, 'r') as f: SITES = f.read().splitlines()
                LEN_SITES = len(SITES)
                PP = str(LEN_SITES)
            except:
                print(f'{R} [-] Cant open sites list{END}')
                exit(0)
        os.system(cmd)
        print(f'{G}[+] {BOLD}Sites: {PP} {BOLD}\n{G}[+] Threads: {(str(THREADING))}{END}')
        SCANNED = 0
        if W:
            with concurrent.futures.ThreadPoolExecutor(max_workers=THREADING) as killz:
                killz.map(w666, SITES)
        if not W:
            w666(SITE)
        print(f'{G}[+] {BOLD} Total Scanned: {Y} ({str(SCANNED)}){END}')
        print(f'{G}[!] {BOLD} Result Saved -> result.txt {END}')
    except KeyboardInterrupt:
        print(f'{BOLD}{G}[+] {BOLD} Total Scanned: {Y} {str(SCANNED)}{END}')
        exit(0)
